import scala.util.Try


object Queries {

  def killJackSparrow(t: Table): Option[Table] =
    queryT(Some(FilterRows(t, Field("name", _ != "Jack"))))

  def insertLinesThenSort(db: Database): Option[Table] = InsertRow(Table("Inserted Fellas", List.empty), List(
    Map("name" -> "Ana", "age" -> "93", "CNP" -> "455550555"),
    Map("name" -> "Diana", "age" -> "33", "CNP" -> "255532142"),
    Map("name" -> "Tatiana", "age" -> "55", "CNP" -> "655532132"),
    Map("name" -> "Rosmaria", "age" -> "12", "CNP" -> "855532172")
  )).eval.map(_.sort("age"))



  def youngAdultHobbiesJ(db: Database): Option[Table] =
    ((Some(db), "SELECT", List("People", "Hobbies")), "JOIN", ("People", "name"), ("Hobbies", "name"), "FILTER", ("People", "age < 25 && name.startsWith('J')"), "EXTRACT", List("name", "hobby")).flatMap(_.eval.flatMap(_.tables.headOption))


}
